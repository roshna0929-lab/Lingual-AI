const service = require("../services/auth.service.cjs");

exports.register = async (req, res, next) => {
  try {
    const data = await service.register(req.body);
    res.status(201).json({ success: true, ...data });
  } catch (err) { next(err); }
};

exports.login = async (req, res, next) => {
  try {
    const data = await service.login(req.body);
    res.json({ success: true, ...data });
  } catch (err) { next(err); }
};

exports.me = async (req, res, next) => {
  try {
    const user = await service.me(req.user.id);
    res.json({ success: true, user });
  } catch (err) { next(err); }
};
