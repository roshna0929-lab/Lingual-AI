const { query } = require("../config/db.cjs");
const { translateText } = require("../services/translation.service.cjs");

exports.create = async (req, res, next) => {
  try {
    const { sourceLanguage, targetLanguage, text } = req.body;
    const translatedText = translateText(sourceLanguage, targetLanguage, text);

    const result = await query(
      `INSERT INTO translations (user_id,source_language,target_language,source_text,translated_text)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id,source_language,target_language,source_text,translated_text,created_at`,
      [req.user.id, sourceLanguage, targetLanguage, text, translatedText]
    );

    await query(
      `INSERT INTO usage (user_id,action,count) VALUES ($1,'translation',1)
       ON CONFLICT (user_id,action) DO UPDATE SET count=usage.count+1,updated_at=NOW()`,
      [req.user.id]
    );

    res.json({ success: true, translation: translatedText, record: result.rows[0] });
  } catch (err) { next(err); }
};

exports.history = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT id,source_language,target_language,source_text,translated_text,created_at
       FROM translations WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`,
      [req.user.id]
    );
    res.json({ success: true, translations: result.rows });
  } catch (err) { next(err); }
};
