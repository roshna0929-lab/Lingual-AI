const jwt = require("jsonwebtoken");
const { JWT_SECRET } = require("../config/env.cjs");

module.exports = function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) return res.status(401).json({ success: false, message: "Authentication required." });
  if (!JWT_SECRET) return res.status(500).json({ success: false, message: "JWT_SECRET is not configured." });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ success: false, message: "Invalid or expired token." });
  }
};
