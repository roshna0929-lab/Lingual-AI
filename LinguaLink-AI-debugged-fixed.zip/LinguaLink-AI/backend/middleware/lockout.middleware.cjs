// Database-backed account lockout can be added here.
// This starter keeps authentication simple and safe while the schema stores
// failed-login information for future lockout policies.
module.exports = function lockoutMiddleware(req, res, next) {
  next();
};
