const dictionary = {
  English: {
    Tamil: {
      "hello": "வணக்கம்",
      "hello!": "வணக்கம்!",
      "how are you": "நீங்கள் எப்படி இருக்கிறீர்கள்?",
      "thank you": "நன்றி",
      "where is the airport": "விமான நிலையம் எங்கே?",
      "i need help": "எனக்கு உதவி தேவை"
    },
    Hindi: { "hello": "नमस्ते", "thank you": "धन्यवाद", "i need help": "मुझे मदद चाहिए" },
    Malayalam: { "hello": "ഹലോ", "thank you": "നന്ദി" },
    Telugu: { "hello": "హలో", "thank you": "ధన్యవాదాలు" },
    Kannada: { "hello": "ನಮಸ್ಕಾರ", "thank you": "ಧನ್ಯವಾದಗಳು" }
  },
  Tamil: {
    English: { "வணக்கம்": "Hello", "நன்றி": "Thank you", "எனக்கு உதவி தேவை": "I need help" }
  },
  Hindi: {
    English: { "नमस्ते": "Hello", "धन्यवाद": "Thank you", "मुझे मदद चाहिए": "I need help" }
  },
  Malayalam: { English: { "ഹലോ": "Hello", "നന്ദി": "Thank you" } },
  Telugu: { English: { "హలో": "Hello", "ధన్యవాదాలు": "Thank you" } },
  Kannada: { English: { "ನಮಸ್ಕાર": "Hello", "ಧನ್ಯವಾದಗಳು": "Thank you" } }
};

function translateText(sourceLanguage, targetLanguage, text) {
  if (sourceLanguage === targetLanguage) return text;

  const input = text.trim();
  const key = /^[\x00-\x7F]*$/.test(input) ? input.toLowerCase() : input;
  const exact = dictionary[sourceLanguage]?.[targetLanguage]?.[key];

  if (exact) return exact;
  return `[Demo ${targetLanguage} translation] ${input}`;
}

module.exports = { translateText };
