const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { query } = require("../config/db.cjs");
const { JWT_SECRET, JWT_EXPIRES_IN } = require("../config/env.cjs");

const LOCKOUT_MINUTES = 15;
const MAX_FAILED_ATTEMPTS = 5;

function tokenFor(user) {
  if (!JWT_SECRET) throw new Error("JWT_SECRET is not configured.");
  return jwt.sign(
    { id: user.id, email: user.email },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function httpError(message, statusCode) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

async function register({ name, email, password }) {
  const existing = await query("SELECT id FROM users WHERE email=$1", [email]);
  if (existing.rowCount) {
    throw httpError("An account with this email already exists.", 409);
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const result = await query(
    `INSERT INTO users (name,email,password_hash)
     VALUES ($1,$2,$3)
     RETURNING id,name,email,created_at`,
    [name, email, passwordHash]
  );

  const user = result.rows[0];

  // Give every new account a free usage bucket.
  await query(
    `INSERT INTO subscriptions (user_id, plan, status)
     VALUES ($1, 'free', 'active')
     ON CONFLICT DO NOTHING`,
    [user.id]
  ).catch(() => {});

  return { user, token: tokenFor(user) };
}

async function login({ email, password }) {
  const result = await query("SELECT * FROM users WHERE email=$1", [email]);
  if (!result.rowCount) {
    throw httpError("Invalid email or password.", 401);
  }

  const user = result.rows[0];
  const now = Date.now();
  const lastFailed = user.last_failed_login
    ? new Date(user.last_failed_login).getTime()
    : 0;
  const lockedUntil = lastFailed + LOCKOUT_MINUTES * 60 * 1000;

  if (user.failed_login_count >= MAX_FAILED_ATTEMPTS && lastFailed && now < lockedUntil) {
    const minutes = Math.ceil((lockedUntil - now) / 60000);
    throw httpError(`Account temporarily locked. Try again in about ${minutes} minute(s).`, 423);
  }

  if (user.failed_login_count >= MAX_FAILED_ATTEMPTS && lastFailed && now >= lockedUntil) {
    await query(
      "UPDATE users SET failed_login_count=0,last_failed_login=NULL WHERE id=$1",
      [user.id]
    );
  }

  const valid = await bcrypt.compare(password, user.password_hash);

  if (!valid) {
    const nextCount = Math.min((user.failed_login_count || 0) + 1, MAX_FAILED_ATTEMPTS);
    await query(
      `UPDATE users
       SET failed_login_count=$1,last_failed_login=NOW()
       WHERE id=$2`,
      [nextCount, user.id]
    );

    // Progressive delay makes repeated guessing more expensive.
    const delayMs = Math.min(1000 * 2 ** Math.max(nextCount - 1, 0), 8000);
    await new Promise(resolve => setTimeout(resolve, delayMs));

    if (nextCount >= MAX_FAILED_ATTEMPTS) {
      console.warn(`Security notice: account ${user.id} is locked for ${LOCKOUT_MINUTES} minutes.`);
    }

    throw httpError("Invalid email or password.", 401);
  }

  await query(
    "UPDATE users SET failed_login_count=0,last_failed_login=NULL,last_login=NOW() WHERE id=$1",
    [user.id]
  );

  const safeUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    created_at: user.created_at
  };

  return { user: safeUser, token: tokenFor(safeUser) };
}

async function me(id) {
  const result = await query(
    "SELECT id,name,email,created_at,last_login FROM users WHERE id=$1",
    [id]
  );

  if (!result.rowCount) {
    throw httpError("User not found.", 404);
  }

  return result.rows[0];
}

module.exports = { register, login, me };
