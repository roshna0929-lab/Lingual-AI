const router = require("express").Router();
const { z } = require("zod");
const validate = require("../middleware/validate.middleware.cjs");
const auth = require("../middleware/auth.middleware.cjs");
const controller = require("../controllers/translation.controller.cjs");

const schema = z.object({
  sourceLanguage: z.string().min(2).max(50),
  targetLanguage: z.string().min(2).max(50),
  text: z.string().trim().min(1).max(5000)
});

router.use(auth);
router.post("/", validate(schema), controller.create);
router.get("/", controller.history);

module.exports = router;
