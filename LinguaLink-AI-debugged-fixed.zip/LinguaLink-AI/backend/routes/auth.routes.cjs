const router = require("express").Router();
const { z } = require("zod");
const validate = require("../middleware/validate.middleware.cjs");
const auth = require("../middleware/auth.middleware.cjs");
const loginRateLimit = require("../middleware/loginRateLimit.middleware.cjs");
const controller = require("../controllers/auth.controller.cjs");

const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(255).transform(v => v.toLowerCase()),
  password: z.string().min(8).max(100)
});

const loginSchema = z.object({
  email: z.string().trim().email().max(255).transform(v => v.toLowerCase()),
  password: z.string().min(1).max(100)
});

router.post("/register", validate(registerSchema), controller.register);
router.post("/login", loginRateLimit, validate(loginSchema), controller.login);
router.get("/me", auth, controller.me);

module.exports = router;
