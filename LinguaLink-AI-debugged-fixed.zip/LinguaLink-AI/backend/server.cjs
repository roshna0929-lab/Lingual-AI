const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const { PORT, FRONTEND_URL } = require("./config/env.cjs");
const authRoutes = require("./routes/auth.routes.cjs");
const translationRoutes = require("./routes/translation.routes.cjs");
const rateLimit = require("./middleware/rateLimit.middleware.cjs");
const errorHandler = require("./middleware/error.middleware.cjs");

const app = express();

const allowedOrigins = new Set([
  FRONTEND_URL,
  "http://localhost:5173",
  "http://127.0.0.1:5173"
]);

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.has(origin)) return callback(null, true);
    return callback(new Error("CORS origin not allowed."));
  },
  credentials: false
}));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));
app.use("/api", rateLimit);

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    service: "LinguaLink AI Backend",
    status: "running"
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/translations", translationRoutes);

app.use((req, res) => {
  res.status(404).json({ success: false, message: "API route not found." });
});

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`LinguaLink AI backend running at http://localhost:${PORT}`);
  console.log(`Frontend allowed at ${FRONTEND_URL}`);
});
