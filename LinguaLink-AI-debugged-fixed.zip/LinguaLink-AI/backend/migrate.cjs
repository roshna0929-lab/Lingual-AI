const fs = require("fs");
const path = require("path");
const { query } = require("./config/db.cjs");

async function migrate() {
  const dir = path.join(__dirname, "migrations");
  const files = fs.readdirSync(dir)
    .filter(name => /^\d+_.*\.sql$/.test(name))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  await query(`
    CREATE TABLE IF NOT EXISTS migration_history (
      version VARCHAR(100) PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  for (const file of files) {
    const existing = await query(
      "SELECT 1 FROM migration_history WHERE version=$1",
      [file]
    );

    if (existing.rowCount) {
      console.log(`Skipping ${file}`);
      continue;
    }

    const sql = fs.readFileSync(path.join(dir, file), "utf8");
    await query("BEGIN");
    try {
      await query(sql);
      await query(
        "INSERT INTO migration_history(version) VALUES($1)",
        [file]
      );
      await query("COMMIT");
      console.log(`Applied ${file}`);
    } catch (error) {
      await query("ROLLBACK");
      throw error;
    }
  }

  console.log("Database migrations complete.");
}

migrate()
  .catch(error => {
    console.error("Migration failed:", error.message);
    process.exitCode = 1;
  });
