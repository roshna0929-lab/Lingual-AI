const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const PORT = Number(process.env.PORT || 5000);
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:5173";
const DATABASE_URL = process.env.DATABASE_URL;
const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

if (!DATABASE_URL) {
  console.warn("DATABASE_URL is not set. Database-backed routes will fail until PostgreSQL is configured.");
}
if (!JWT_SECRET) {
  console.warn("JWT_SECRET is not set. Authentication will fail until it is configured.");
}

module.exports = { PORT, FRONTEND_URL, DATABASE_URL, JWT_SECRET, JWT_EXPIRES_IN };
