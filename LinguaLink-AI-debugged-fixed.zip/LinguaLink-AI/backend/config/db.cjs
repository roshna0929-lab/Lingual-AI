const { Pool } = require("pg");
const { DATABASE_URL } = require("./env.cjs");

const pool = DATABASE_URL
  ? new Pool({ connectionString: DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false })
  : null;

async function query(text, params) {
  if (!pool) throw new Error("DATABASE_URL is not configured.");
  return pool.query(text, params);
}

module.exports = { pool, query };
