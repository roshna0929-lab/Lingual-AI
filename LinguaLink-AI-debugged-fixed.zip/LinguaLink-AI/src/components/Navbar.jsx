import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const loggedIn = Boolean(localStorage.getItem("lingualink_token"));

  function logout() {
    localStorage.removeItem("lingualink_token");
    localStorage.removeItem("lingualink_user");
    navigate("/");
  }

  return (
    <nav className="nav">
      <Link className="brand" to="/">LinguaLink AI</Link>
      <div className="nav-links">
        <Link to="/">Home</Link>
        {loggedIn ? (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/translator">Translator</Link>
            <button className="link-button" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link className="button small" to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
