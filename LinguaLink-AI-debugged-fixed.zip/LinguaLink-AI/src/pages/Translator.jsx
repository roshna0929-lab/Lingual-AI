import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import { api } from "../services/api";

const languages = ["English", "Tamil", "Hindi", "Malayalam", "Telugu", "Kannada"];

export default function Translator() {
  const [sourceLanguage, setSourceLanguage] = useState("English");
  const [targetLanguage, setTargetLanguage] = useState("Tamil");
  const [text, setText] = useState("");
  const [translation, setTranslation] = useState("");
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.history()
      .then(data => setHistory(data.translations || []))
      .catch(err => setError(err.message));
  }, []);

  async function translate() {
    if (!text.trim()) return;
    setLoading(true);
    setError("");
    try {
      const data = await api.translate({
        sourceLanguage,
        targetLanguage,
        text
      });
      setTranslation(data.translation);
      setHistory(prev => [data.record, ...prev].slice(0, 10));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="container">
        <h1>Translator</h1>
        <p className="muted">Demo translation engine connected to the Node.js API.</p>
        {error && <div className="error">{error}</div>}
        <div className="translator-grid">
          <section className="card">
            <div className="language-row">
              <label>From<select value={sourceLanguage} onChange={e => setSourceLanguage(e.target.value)}>{languages.map(l => <option key={l}>{l}</option>)}</select></label>
              <label>To<select value={targetLanguage} onChange={e => setTargetLanguage(e.target.value)}>{languages.map(l => <option key={l}>{l}</option>)}</select></label>
            </div>
            <textarea rows="8" placeholder="Type something..." value={text} onChange={e => setText(e.target.value)} />
            <button className="button" onClick={translate} disabled={loading}>{loading ? "Translating..." : "Translate"}</button>
          </section>
          <section className="card result">
            <span className="badge">Result</span>
            <h2>{translation || "Your translation will appear here."}</h2>
          </section>
        </div>
        <section className="card history">
          <h2>Recent translations</h2>
          {history.length === 0 ? <p className="muted">No translations yet.</p> : history.map(item => (
            <div className="history-item" key={item.id}>
              <div><strong>{item.source_language} → {item.target_language}</strong><p>{item.source_text}</p></div>
              <p>{item.translated_text}</p>
            </div>
          ))}
        </section>
      </main>
    </>
  );
}
