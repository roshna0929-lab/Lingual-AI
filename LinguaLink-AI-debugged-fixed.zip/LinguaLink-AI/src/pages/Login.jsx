import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { api } from "../services/api";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api.login(form);
      localStorage.setItem("lingualink_token", data.token);
      localStorage.setItem("lingualink_user", JSON.stringify(data.user));
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="auth-page">
        <form className="card form" onSubmit={submit}>
          <h1>Welcome back</h1>
          <p>Sign in to your LinguaLink AI account.</p>
          {error && <div className="error">{error}</div>}
          <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></label>
          <label>Password<input type="password" required value={form.password} onChange={e => setForm({...form, password: e.target.value})} /></label>
          <button className="button" disabled={loading}>{loading ? "Signing in..." : "Login"}</button>
          <p>Don't have an account? <Link to="/register">Register</Link></p>
        </form>
      </main>
    </>
  );
}
