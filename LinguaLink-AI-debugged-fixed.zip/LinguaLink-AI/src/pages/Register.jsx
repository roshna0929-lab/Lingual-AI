import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { api } from "../services/api";

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api.register(form);
      localStorage.setItem("lingualink_token", data.token);
      localStorage.setItem("lingualink_user", JSON.stringify(data.user));
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="auth-page">
        <form className="card form" onSubmit={submit}>
          <h1>Create account</h1>
          <p>Start using LinguaLink AI.</p>
          {error && <div className="error">{error}</div>}
          <label>Name<input required value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></label>
          <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></label>
          <label>Password<input type="password" minLength="8" required value={form.password} onChange={e => setForm({...form, password: e.target.value})} /></label>
          <button className="button" disabled={loading}>{loading ? "Creating..." : "Create account"}</button>
          <p>Already registered? <Link to="/login">Login</Link></p>
        </form>
      </main>
    </>
  );
}
