import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="hero">
        <div className="hero-copy">
          <span className="badge">AI-powered multilingual communication</span>
          <h1>Break language barriers with <span>LinguaLink AI</span>.</h1>
          <p>
            A communication platform designed around speech translation,
            text conversion, accessibility and future wearable integration.
          </p>
          <div className="actions">
            <Link className="button" to="/register">Get started</Link>
            <Link className="button secondary" to="/login">Sign in</Link>
          </div>
        </div>
        <div className="hero-card">
          <div className="orb">LL</div>
          <h2>Multimodal communication</h2>
          <p>Speech → Text → Translation → Speech</p>
          <p>Designed to expand toward sign-language recognition and wearable devices.</p>
        </div>
      </main>
    </>
  );
}
