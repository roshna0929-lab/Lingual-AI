import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";

export default function Dashboard() {
  let user = {};
  try {
    user = JSON.parse(localStorage.getItem("lingualink_user") || "{}");
  } catch {
    localStorage.removeItem("lingualink_user");
  }

  return (
    <>
      <Navbar />
      <main className="container">
        <div className="dashboard-head">
          <div>
            <span className="badge">Dashboard</span>
            <h1>Hello, {user.name || "User"} 👋</h1>
            <p>Manage your multilingual communication experience.</p>
          </div>
          <Link className="button" to="/translator">Open Translator</Link>
        </div>
        <div className="grid three">
          <div className="card"><h3>Translation</h3><p>Translate text between supported languages.</p></div>
          <div className="card"><h3>History</h3><p>Your completed translations are stored by the backend.</p></div>
          <div className="card"><h3>Future wearable</h3><p>Architecture can expand toward earbuds, collar speaker and camera modules.</p></div>
        </div>
      </main>
    </>
  );
}
