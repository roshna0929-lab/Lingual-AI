# LinguaLink AI

React + Vite frontend connected to a Node.js + Express API with PostgreSQL persistence.

## Frontend ↔ backend connection

- Frontend: `http://localhost:5173`
- Backend: `http://localhost:5000`
- Frontend API client: `src/services/api.js`
- Development proxy: Vite forwards `/api/*` to the backend.
- Production can set `VITE_API_URL` to the deployed API URL.
- Backend CORS allows the configured frontend URL plus local Vite hosts.

## Setup

From the **LinguaLink-AI** root folder:

```powershell
npm install
```

Create `backend/.env` from `backend/.env.example` and set:

```text
PORT=5000
FRONTEND_URL=http://localhost:5173
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/lingualink
JWT_SECRET=use_a_long_random_secret
JWT_EXPIRES_IN=7d
```

Make sure the PostgreSQL database `lingualink` exists, then run:

```powershell
npm run migrate
```

Start the backend:

```powershell
npm run backend
```

In a second terminal start the frontend:

```powershell
npm run dev
```

Open `http://localhost:5173`.

Test the backend directly at:

```text
http://localhost:5000/api/health
```

## Authentication/security

- JWT authentication
- bcrypt password hashing with 12 rounds
- protected translation/history routes
- login IP rate limit: 10 requests/minute
- account lockout after 5 failed password attempts for 15 minutes
- progressive delay after failed login attempts
- Helmet + CORS + request validation
- No secrets in frontend code

## Translation

The current translation service is a **working demo dictionary**, not a real AI model. Unknown phrases intentionally return a demo marker. Replace `backend/services/translation.service.cjs` with a real translation provider later.

## Important

Do not commit `backend/.env` or any API keys/passwords. Only commit the `.env.example` files.
